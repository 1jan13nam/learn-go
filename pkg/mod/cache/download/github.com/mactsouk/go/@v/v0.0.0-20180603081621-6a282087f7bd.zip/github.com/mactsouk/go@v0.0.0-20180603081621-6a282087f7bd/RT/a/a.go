package a

import (
"fmt"
)

func init() {
  fmt.Println("Hello World from Package a!")
}

