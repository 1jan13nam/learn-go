package b

import (
"fmt"
)

func init() {
  fmt.Println("Hello World from Package b!")
}

