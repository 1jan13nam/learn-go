# go

# A simple Go package used in a tutorial
# A naive Go project that will be used for testing
