package simpleGitHub

func AddTwo(x, y int) int {
	return x + y
}
